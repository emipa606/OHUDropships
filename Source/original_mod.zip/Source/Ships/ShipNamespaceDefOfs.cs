﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using RimWorld;
using Verse;
using Verse.AI;

namespace OHUShips
{
    [DefOf]
    public class ShipNamespaceDefOfs
    {
        public static WorldObjectDef ShipTracker;
        public static WorldObjectDef ShipDropSite;

        public static JobDef UninstallShipWeapon;

        public static JobDef InstallShipWeapon;
        public static JobDef EnterShip;
        public static JobDef LoadContainerMultiplePawns;

        public static JobDef LeaveInShip;
        public static JobDef RescueToShip;

        public static DutyDef LeaveInShipDuty;
        public static DutyDef StealForShipDuty;

        public static DutyDef LoadShipCargoDuty;   

        public static ThingDef Chemfuel;

        public static WorldObjectDef WorldShip;

        public static object Shi { get; internal set; }
    }
}
