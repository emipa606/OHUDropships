﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace OHUShips
{
    public enum ShipState
    {
        Stationary,
        Incoming,
        Outgoing
    }
}
