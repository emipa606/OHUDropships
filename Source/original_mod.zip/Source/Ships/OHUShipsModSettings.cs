﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using Verse;

namespace OHUShips
{
    public class OHUShipsModSettings : ModSettings
    {
        public static bool CargoLoadingActive;
    }
}
